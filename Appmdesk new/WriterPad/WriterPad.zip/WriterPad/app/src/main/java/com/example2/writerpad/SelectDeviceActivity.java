package com.example2.writerpad;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.example2.writerpad.R;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.Arrays;
import java.util.List;

import Adapter.SelectDeviceAdapter;

public class SelectDeviceActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_device);
        List<WeighingMachineDetails> listOfWeighingMachineDetails = Arrays.asList(new WeighingMachineDetails("NTC-1", "Available to connect"), new WeighingMachineDetails("NTC-2", "Available to connect"), new WeighingMachineDetails("NTC-3", "Conneced to UserName"), new WeighingMachineDetails("NTC-4", "Available to Connect"), new WeighingMachineDetails("NTC-5", "Connected to UserName"), new WeighingMachineDetails("NTC-6", "Available to Connect"), new WeighingMachineDetails("NTC-7", "Available to Connect"), new WeighingMachineDetails("NTC-8", "Available to Connect"), new WeighingMachineDetails("NTC-9", "Available to Connect"));
        recyclerView = findViewById(R.id.selectDeviceRecyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        SelectDeviceAdapter selectDeviceAdapter = new SelectDeviceAdapter(this, listOfWeighingMachineDetails);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(selectDeviceAdapter);
        bottomNavigationView = findViewById(R.id.bottomNavigationView2);
        bottomNavigationView.getMenu().getItem(0).setCheckable(false);
        oClickBottomNavigationBar();

    }
    public static final int REFRESH_ICON_ID = R.id.refreshicon;
    public static final int LOGS_ICON_ID = R.id.logsicon;
    public static final int SHEET_TRANSFER_ID = R.id.sheet_transfer;
    public static final int CONNECT_ICON_ID = R.id.connecticon;

    //    private void oClickBottomNavigationBar() {
//        bottomNavigationView.setOnItemReselectedListener(new NavigationBarView.OnItemReselectedListener() {
//            @Override
//            public void onNavigationItemReselected(@NonNull MenuItem item) {
//                switch (item.getItemId()) {
//                    case R.id.refreshicon:
//                      bottomNavigationView.getMenu().getItem(0).setCheckable(true);
//                        break;
//                    case R.id.logsicon:
//                        openLogsActitvity();
//                        break;
//                    case R.id.sheet_transfer:
//                        break;
//                    case R.id.connecticon:
//                        break;
//                    default: break;
//
//                }
//
//
//            }
//
//
//        });
//    }
    private void oClickBottomNavigationBar() {
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case (REFRESH_ICON_ID):
openn();
                        break;
                    case (LOGS_ICON_ID):
op();
                        break;
                    case (SHEET_TRANSFER_ID):
opii();
                        break;
                    default:
                        Toast.makeText(SelectDeviceActivity.this, "YO", Toast.LENGTH_LONG).show();
                        bottomNavigationView.getMenu().clear();
                        bottomNavigationView.inflateMenu(R.menu.bottom_menubar);
                        break;
                }
                return true;
            }
        });
    }

    private void opii() {
    }

    private void op() {
    }

    private void openn() {
    }


}